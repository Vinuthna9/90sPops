90's Ice Pops — Static Brand Showcase

Files:
- index.html: complete responsive static website (HTML, CSS and JavaScript in one file)

Preview:
Open index.html in a modern browser.

Hostinger deployment:
1. Purchase/activate a hosting plan and connect the domain.
2. Open hPanel > Websites > Manage > File Manager.
3. Open public_html.
4. Upload index.html (or upload the ZIP and extract it).
5. Visit your domain and test on mobile and desktop.

Before publishing:
- Confirm the contact email and replace hello@90sicepops.com if needed.
- Add the business phone number, social links and location if desired.
- Replace the CSS ice-pop illustrations with the brand's original product photographs when supplied.
- Confirm the wording around ingredients and Vitamin C with the business owner before making public claims.
- Creamy Milk Pops flavours are intentionally not listed because they were not confirmed in the reference video.

This is a front-end-only static website. It has no database, login, cart, checkout, payment gateway or admin panel. Google Fonts require an internet connection; the page otherwise uses local HTML/CSS/JS.
