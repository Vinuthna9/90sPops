# 90’s Ice Pops — static brand website

Plain HTML + CSS + vanilla JavaScript. No build step, backend, database or cart.

```
90s-ice-pops/
├── index.html          ← entry page
├── css/style.css
├── js/main.js          ← contact details + flavour copy are edited here
└── assets/images/{logo,products,fruits,backgrounds}  assets/videos  assets/icons
```

## Test locally
Open `index.html` in a browser (double-click), or run `python3 -m http.server` in this folder and visit http://localhost:8000.

## Deploy to Hostinger
1. hPanel → **Websites → Manage → File Manager** → open `public_html`.
2. Delete the default placeholder file (`default.php` / `index.php`) if present.
3. Upload `90s-ice-pops.zip` into `public_html`, right-click → **Extract**, and move the *contents* of the extracted folder so that `index.html` sits directly in `public_html`.
4. **Domain:** hPanel → **Domains** → point the domain to this hosting plan (or update nameservers to Hostinger’s), allow up to 24 h to propagate.
5. **SSL:** hPanel → **Security → SSL** → install the free SSL for the domain, then switch on **Force HTTPS**.

## Before you publish — owner checklist
- **Contact details:** open `js/main.js`, fill the `CONTACT` object (phone, email, address, official social URLs). Empty fields stay hidden. The brochure prints an OM Enterprises Vijayawada address and an order number; they are *not* used until you confirm them.
- **Quality claims** (NO artificial sweeteners / preservatives / gelatine; 100% pure RO water / approved flavour / hygienic packing) come from the brochure. Confirm they are still accurate (edit in `index.html`, section “quality”).
- **Price (₹10):** deliberately not shown.
- **Fruity Ice Pops / Creamy Milk Pops** from the old site are not included; add them only if still offered. The Doodley Chocolates brand is excluded.

## Hero video (optional)
Add a short, compressed, muted loop as `assets/videos/hero.mp4` (and optionally `hero.webm`, under ~3 MB). If the files are absent, the site silently uses the animated image fallback. Replace `assets/images/backgrounds/hero-poster.jpg` with a nicer poster frame if you like.

## Image quality note
Product, logo and mascot images were cut from the supplied brochure JPG/PNGs (≈640–1280 px), so they are soft above ~450 px. For a sharper site, replace the files in `assets/images/` (same filenames) with the original print artwork exported as transparent PNG/WebP.

## Fonts
Google Fonts (Lilita One, Poppins, Caveat) load from the internet; system fonts are used if offline.
