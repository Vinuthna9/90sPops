/* =========================================================
   90’s Ice Pops — behaviour (vanilla JS, no dependencies)
   ========================================================= */
(function () {
  'use strict';

  /* ---------------------------------------------------------
     EDIT HERE: official contact details.
     Leave a value empty ('') to keep that item hidden.
     Social links: add only official URLs, e.g. { Instagram: 'https://…' }
     --------------------------------------------------------- */
  var CONTACT = {
    phone: '',
    email: '',
    address: '',
    social: {}
  };

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Flavour data for the modal ---------- */
  var FLAVOURS = {
    orange:    { name: 'Orange Burst',     c: '#f7931e', c2: '#ffd08a', pack: 'assets/images/products/pack-orange.png',    cube: 'assets/images/fruits/cube-orange.png',
                 desc: 'Zesty and vibrant, this citrus classic is a summer favourite. Perfectly sweet with just the right tang!' },
    grape:     { name: 'Grape Blast',      c: '#8a4fbf', c2: '#d6bdf0', pack: 'assets/images/products/pack-grape.png',     cube: 'assets/images/fruits/cube-grape.png',
                 desc: 'A juicy explosion of dark grape flavour — bold, rich and refreshing. Kids love it, adults crave it!' },
    blueberry: { name: 'Blueberry Freeze', c: '#12a6d8', c2: '#a7e3f6', pack: 'assets/images/products/pack-blueberry.png', cube: 'assets/images/fruits/cube-blueberry.png',
                 desc: 'A cool, slightly tart pop that\'s bursting with berry goodness. Naturally bold and antioxidant-rich flavour.' },
    cola:      { name: 'Cola Crunch',      c: '#c8203a', c2: '#f2a0ab', pack: 'assets/images/products/pack-cola.png',      cube: 'assets/images/fruits/cube-cola.png',
                 desc: 'Classic cola with an icy twist. Fizzy, nostalgic, and oh-so-cool! Bring back the good old days in every bite.' }
  };

  /* ---------- Navigation: sticky state, mobile menu, active link ---------- */
  var nav = document.getElementById('nav');
  var toggle = document.getElementById('navToggle');
  var menu = document.getElementById('navMenu');

  function onScrollNav() { nav.classList.toggle('is-stuck', window.scrollY > 24); }
  onScrollNav();
  window.addEventListener('scroll', onScrollNav, { passive: true });

  function setMenu(open) {
    menu.classList.toggle('is-open', open);
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }
  toggle.addEventListener('click', function () { setMenu(!menu.classList.contains('is-open')); });
  menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
  window.addEventListener('resize', function () { if (window.innerWidth > 820) setMenu(false); });

  var links = [].slice.call(menu.querySelectorAll('li a'));
  var map = {};
  links.forEach(function (a) { map[a.getAttribute('href').slice(1)] = a; });
  // sections that belong to a nav item
  var belongs = { home: 'home', products: 'products', stories: 'products', about: 'about', why: 'why', quality: 'why', cta: 'contact', contact: 'contact' };
  if ('IntersectionObserver' in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        var key = belongs[en.target.id];
        links.forEach(function (a) { a.classList.remove('is-active'); });
        if (map[key]) map[key].classList.add('is-active');
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    Object.keys(belongs).forEach(function (id) { var el = document.getElementById(id); if (el) spy.observe(el); });
  }

  /* ---------- Scroll reveal ---------- */
  var revealEls = [].slice.call(document.querySelectorAll('.reveal'));
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); obs.unobserve(en.target); } });
    }, { threshold: 0.15, rootMargin: '0px 0px -6% 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('is-in'); });
  }

  /* ---------- Gentle parallax (data-speed) ---------- */
  var para = [].slice.call(document.querySelectorAll('[data-speed]'));
  var ticking = false;
  function parallax() {
    var vh = window.innerHeight;
    para.forEach(function (el) {
      var r = el.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) return;
      var center = r.top + r.height / 2 - vh / 2;
      el.style.setProperty('--py', (center * parseFloat(el.dataset.speed) * -1).toFixed(1) + 'px');
    });
    ticking = false;
  }
  if (!reduceMotion && para.length) {
    window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(parallax); } }, { passive: true });
    window.addEventListener('resize', parallax);
    parallax();
  }

  /* ---------- Hero video: use it only if it can actually play ---------- */
  var video = document.getElementById('heroVideo');
  if (video) {
    var off = function () { video.classList.add('is-off'); };
    video.addEventListener('error', off, true);
    var sources = video.querySelectorAll('source');
    sources.forEach(function (s) { s.addEventListener('error', function () {
      if (s === sources[sources.length - 1]) off();
    }); });
    if (reduceMotion) { off(); }
    var p = video.play && video.play();
    if (p && p.catch) p.catch(off);
  }

  /* ---------- Scatter decorative fruit from data-fruit="a.svg,b.svg,…" ---------- */
  document.querySelectorAll('[data-fruit]').forEach(function (box) {
    box.dataset.fruit.split(',').forEach(function (file, i) {
      var img = document.createElement('img');
      img.className = 'fx fx' + (i + 1);
      img.src = 'assets/images/fruits/' + file.trim();
      img.alt = ''; img.setAttribute('aria-hidden', 'true'); img.loading = 'lazy'; img.decoding = 'async';
      box.appendChild(img);
    });
  });

  /* ---------- Product modal ---------- */
  var modal = document.getElementById('modal');
  var lastBtn = null;
  function openModal(key, btn) {
    var f = FLAVOURS[key]; if (!f) return;
    lastBtn = btn;
    modal.style.setProperty('--c', f.c);
    modal.style.setProperty('--c2', f.c2);
    document.getElementById('modalTitle').textContent = f.name;
    document.getElementById('modalDesc').textContent = f.desc;
    var pk = document.getElementById('modalPack'); pk.src = f.pack; pk.alt = f.name + ' ice pop in its original packaging';
    document.getElementById('modalCube').src = f.cube;
    if (typeof modal.showModal === 'function') modal.showModal(); else modal.setAttribute('open', '');
  }
  function closeModal() {
    if (typeof modal.close === 'function') modal.close(); else modal.removeAttribute('open');
    if (lastBtn) lastBtn.focus();
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-open]');
    if (b) openModal(b.dataset.open, b);
    if (e.target.closest('#modalClose')) closeModal();
    if (e.target === modal) closeModal(); // click on backdrop
  });

  /* ---------- Contact details ---------- */
  function fillContact() {
    var any = false;
    var list = document.getElementById('contactList');
    var foot = document.getElementById('footerContactList');
    function show(field, fn) {
      var li = list.querySelector('[data-field="' + field + '"]'); if (!li) return;
      li.hidden = false; any = true; fn(li.querySelector('[data-value]'));
    }
    function footLine(node) { var li = document.createElement('li'); li.appendChild(node); foot.appendChild(li); }
    if (CONTACT.phone) {
      show('phone', function (a) { a.textContent = CONTACT.phone; a.href = 'tel:' + CONTACT.phone.replace(/[^\d+]/g, ''); });
      var tp = document.createElement('a'); tp.textContent = CONTACT.phone; tp.href = 'tel:' + CONTACT.phone.replace(/[^\d+]/g, ''); footLine(tp);
    }
    if (CONTACT.email) {
      show('email', function (a) { a.textContent = CONTACT.email; a.href = 'mailto:' + CONTACT.email; });
      var te = document.createElement('a'); te.textContent = CONTACT.email; te.href = 'mailto:' + CONTACT.email; footLine(te);
    }
    if (CONTACT.address) {
      show('address', function (p) { p.textContent = CONTACT.address; });
      var ta = document.createElement('span'); ta.textContent = CONTACT.address; footLine(ta);
    }
    var names = Object.keys(CONTACT.social || {});
    if (names.length) {
      show('social', function (box) {
        names.forEach(function (n) {
          var a = document.createElement('a'); a.href = CONTACT.social[n]; a.textContent = n; a.target = '_blank'; a.rel = 'noopener';
          box.appendChild(a);
        });
      });
      names.forEach(function (n) {
        var a = document.createElement('a'); a.href = CONTACT.social[n]; a.textContent = n; a.target = '_blank'; a.rel = 'noopener'; footLine(a);
      });
    }
    document.getElementById('contactSoon').hidden = any;
    document.getElementById('footerContact').hidden = !any;
  }
  fillContact();

  document.getElementById('year').textContent = new Date().getFullYear();
})();
